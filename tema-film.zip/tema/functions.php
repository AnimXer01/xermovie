<?php
/**
 * Özel Tema Fonksiyonları
 *
 * @since Keremiya 5.0
 */
require (get_template_directory() . '/inc/includes.php');

/**
 * Özel Keremiya Tema Paneli
 *
 * @since Keremiya 5.0
 */
require (get_template_directory() . '/panel/keremiya.php');

/* Kendi kodlarızı aşağıya ekleyebilirsiniz */

?>