<?php get_header();?>
<div id="content">
<div class="content wrapper clearfix">

	<div class="olmayansayfa">
		<?php _k('404!'); ?>
<?php
//header("HTTP/1.1 301 Moved Permanently");
//header("Location: ".get_bloginfo('url'));
//exit();
?>
	</div>


</div><!--content-wrapper-->
</div><!--#content-->
<?php get_footer(); ?>