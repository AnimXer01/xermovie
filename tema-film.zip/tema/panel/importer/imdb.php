<?php
/*
 * IMDB BOTU
 */

add_action('wp_ajax_nopriv_keremiya_imdb_importer', 'keremiya_imdb_importer');
add_action('wp_ajax_keremiya_imdb_importer', 'keremiya_imdb_importer');

function keremiya_imdb_importer() {
	// IMDB ID
	$id = $_POST['id'];
	// GET IMDB DATA
	if( ! keremiya_get_option('omdb_api_disable') ) {
		$data = keremiya_get_imdb($id);
	} else {
		$data = keremiya_get_imdb_local($id);
	}

	if($data->Response != 'True')
		return;

	$awards = imdb_replace_awards( $data->Awards );
	$writer = imdb_replace_writer( $data->Writer );
	$categories = imdb_get_category_ids( $data->Genre );
	$released = imdb_replace_date( $data->Released );

	$newData = array(
		array('id' => 'diger-adlari', 	'text' => imdb_empty( $data->Title ) ),
		array('id' => 'yapim', 			'text' => imdb_empty( $data->Year ) ),
		array('id' => 'yayin-tarihi', 	'text' => imdb_empty( $released ) ),
		array('id' => 'yonetmen', 		'text' => imdb_empty( $data->Director ) ),
		array('id' => 'oyuncular', 		'text' => imdb_empty( $data->Actors ) ),
		array('id' => 'senaryo', 		'text' => imdb_empty( $writer ) ),
		array('id' => 'oduller', 		'text' => imdb_empty( $awards ) ),
		array('id' => 'imdb', 			'text' => imdb_empty( $data->imdbRating ) ),
		array('id' => 'resim', 			'text' => imdb_empty( $data->Poster ) ),
		array('id' => 'category', 		'text' => imdb_empty( $categories ) ),
		'count' => 10,
		'response' => true
	);

	$json = json_encode($newData);
	echo $json;

	exit();
}

function keremiya_get_imdb($id) {
	$themeKey = 'e6d6c243'; // Keremiya OMDB API Default Api Key
	$userKey = keremiya_get_option('omdb_api_key'); // User custom api key
	$key = $userKey ? $userKey : $themeKey;

	$url = "http://www.omdbapi.com/?apikey={$key}&i={$id}&plot=short&r=json";
	$response = wp_remote_get( $url );

	if( is_array($response) ) {
		$header = $response['headers']; // array of http header lines
		$data = $response['body']; // use the content
		$data = json_decode($data);

		if( ! $data->Response )
			return;

		return apply_filters('keremiya_imdb_data', $data);
	}

	return false;
}

function imdb_empty($data) {
	if($data == 'N/A')
		return '';

	return $data;
}

function imdb_get_category_ids($content) {
	if(!keremiya_get_option('auto_category'))
		return;

	if( ! keremiya_get_option('omdb_api_disable') )
		$categories = explode(',', $content);

	foreach ($categories as $key => $value) {
		$category[] = imdb_get_genre_id( $value );
	}

	return $category;
}

function imdb_get_genre_id($name) {
	$category_id = keremiya_get_option('imdb_' . trim($name));

	return $category_id;
}

function imdb_genres() {
	$genres = array(
		'Action', 
		'Adventure',
		'Comedies',
		'Crime',
		'Fantasy',
		'Mystery',
		'Drama',
		'Animation',
		'Sci-Fi',
		'Thrillers',
		'Family',
		'Romance',
		'Horror',
		'Sport',
		'War',
		'Westerns',
		'Documentaries',
		'History',
		'Music',
		'Biographies',
		'Musicals',
	);
	
	return apply_filters('imdb_genres', $genres);
}

function imdb_replace_date($text) {
	if( get_option('WPLANG') != 'tr_TR' ) {
		return $text;
	}

	$search = array('Apr', 'May', 'Jan', 'Mar', 'Jun', 'Jul', 'Oct', 'Dec', 'Sept', 'Nov', 'Aug', 'Feb');
	$replace = array('Nisan', 'Mayıs', 'Ocak', 'Mart', 'Haziran', 'Temmuz', 'Ekim', 'Aralık', 'Eylül', 'Kasım', 'Ağustos', 'Şubat');

	$dateText = str_replace($search, $replace, $text);

	return $dateText;
}

function imdb_replace_writer($text) {
	if( get_option('WPLANG') != 'tr_TR' ) {
		return $text;
	}

	$newText = preg_replace("#\((.*?)\)#", '', $text);
	$newText = str_replace(' ,', ',', $newText);

	return $newText;
}

function imdb_replace_awards($text) {
	if( get_option('WPLANG') != 'tr_TR' ) {
		return $text;
	}

	$d = explode('.', $text);

	if($d[0]) {
		$won = 'Won';

		$pos = strpos($d[0], $won);

		if ($pos !== false) {
			$search = array('Won', 'Oscars.', 'Oscar.', 'Emmys.', 'Emmy.', 'Golden Globes.', 'Golden Globe.');
			$replace = array('', 'Oscar Kazandı.', 'Oscar Kazandı.', 'Emmy Kazandı.', 'Emmy Kazandı.', 'Golden Globe Kazandı.', 'Golden Globe Kazandı.');

			$oscarText = str_replace($search, $replace, $d[0].'.');
			//echo $oscarText;
		}

		$nominated = 'Nominated';

		$pos = strpos($d[0], $nominated);

		if ($pos !== false) {
			$search = array('Nominated for', 'Oscars.', 'Oscar.', 'Emmys.', 'Emmy.', 'Golden Globes.', 'Golden Globe.');
			$replace = array('', 'Oscar Adaylığı.', 'Oscar Adaylığı.', 'Emmy Adaylığı.', 'Emmy Adaylığı.', 'Golden Globe Adaylığı.', 'Golden Globe Adaylığı.');

			$nominatedText = str_replace($search, $replace, $d[0].'.');
			//echo $nominatedText;
		}

		$win = 'win';

		$pos = strpos($d[0], $win);

		if ($pos !== false) {
			$search = array('Another', 'wins', 'win', 'nominations');
			$replace = array('Diğer', 'ödül', 'ödül', 'Adaylık.');

			$winText = str_replace($search, $replace, $d[0]);
			//echo $winText;
		}
	}

	if($d[1]) {

		$search = array('Another', 'wins', 'win', 'nominations');
		$replace = array('Diğer', 'ödül', 'ödül',  'adaylık.');

		$anotherText = str_replace($search, $replace, $d[1]);

		//echo $anotherText;
	}

	return trim( $oscarText . $nominatedText . $winText . $anotherText );
}

function keremiya_get_imdb_local($id) {

	$url = "http://akas.imdb.com/title/{$id}/";

	$response = wp_remote_get( $url );

	if( is_array($response) ) {
		$header = $response['headers']; // array of http header lines
		$raw = $response['body']; // use the content

		$data = new StdClass();

		/**
		*	Film Adı
		*/
		preg_match("/property='og:title' content=\"(.*)\"/", $raw, $titleRaw);
		$data->Title = @$titleRaw[1];
		$data->Title = preg_replace("#\((.*?)\)#", '', $data->Title);

		/**
		*	Film Yapım Yılı
		*/
		preg_match('/\((.*?)\)/', @$titleRaw[1], $yearRaw);
		$data->Year = @$yearRaw[1];

		/**
		*	Film Yayın Tarihi
		*/
		preg_match("/itemprop=\"datePublished\" content=\"(.*)\"/", $raw, $releasedRaw);
		$data->Released = @$releasedRaw[1];

		/**
		*	Film Puanı
		*/
		preg_match("/<span itemprop=\"ratingValue\">(.*)<\/span><\/strong>/", $raw, $ratingRaw);
		$data->imdbRating = @$ratingRaw[1];

		/**
		*	Film Kategorileri
		*/
	    preg_match('/Genres:\s*<\/h4>(.+?)<\/div>/si', $raw, $ary);
	    preg_match_all('/<a.*?href="\/genres?\/.+?".*?>(.+?)<\/a>/si', $ary[1], $ary, PREG_PATTERN_ORDER);
	    foreach($ary[1] as $genre)
	    {
	        $data->Genre[] = trim($genre);
	    }

		/**
		*	Film Ödülleri
		*/
		preg_match_all('/itemprop="awards">(.*?)<\/span>/si', $raw, $awardsRaw);
		$awards = $awardsRaw[1][0] . $awardsRaw[1][1];
		$data->Awards = trim( strip_tags( $awards ) );
		$data->Awards = preg_replace( "/\r|\n/", "", $data->Awards );
		$data->Awards = preg_replace('/\s+/', ' ', $data->Awards);
		$data->Awards = str_replace('&amp;', '&', $data->Awards);

		/**
		*	Film Yönetmenleri
		*/
	    preg_match('/Directors?:\s*<\/h4>(.+?)<\/div>/si', $raw, $ary);
	    preg_match_all('/<a.*?href="\/name\/nm.+?".*?>(.+?)<\/a>/si', $ary[1], $ary, PREG_PATTERN_ORDER);
	    // TODO: Update templates to use multiple directors
	    $data->Director = trim(strip_tags(join(', ', $ary[1])));

		/**
		*	Film Senaristleri
		*/
	    preg_match('/Writers?:\s*<\/h4>(.+?)<\/div>/si', $raw, $ary);
	    preg_match_all('/<a.*?href="\/name\/nm.+?".*?>(.+?)<\/a>/si', $ary[1], $ary, PREG_PATTERN_ORDER);
	    // TODO: Update templates to use multiple writers
	    $data->Writer = trim(strip_tags(join(', ', $ary[1])));

		/**
		*	Film Oyuncuları
		*/
	    if (preg_match('#<table class="cast_list">(.*)#si', $raw, $match))
	    {
	        // no idea why it does not always work with (.*?)</table
	        // could be some maximum length of .*?
	        // anyways, I'm cutting it here
	        $casthtml = substr($match[1],0,strpos( $match[1],'</table'));
	        if (preg_match_all('#<td .*? itemprop="actor".*?>\s+<a href="/name/(nm\d+)/?.*?".*?>(.*?)</a>.*?<td class="character">(.*?)</td>#si', $casthtml, $ary, PREG_PATTERN_ORDER))
	        {
	            for ($i=0; $i < sizeof($ary[0]); $i++)
	            {
	                $actorid    = trim(strip_tags($ary[1][$i]));
	                $actor      = trim(strip_tags($ary[2][$i]));
	                $character  = trim( preg_replace('/\s+/', ' ', strip_tags( preg_replace('/&nbsp;/', ' ', $ary[3][$i]))));
	                $cast[]		= $actor;
	            }
	        }
	        // remove html entities and replace &nbsp; with simple space
	        $data->Actors = join(', ', $cast);
	        // sometimes appearing in series (e.g. Scrubs)
	        $data->Actors = preg_replace('#/ ... #', '', $data->Actors);
	    }

		/**
		*	Film Posteri
		*/
		if (preg_match('/<div.*?class="poster".*?<img.*?src="(.*?\.)_v.*?"/si', $raw, $ary))
	    {
	        if ($ary[1]) 
	        {
				$img_url = $ary[1]."jpg";
				// Replace the https with http.
				$img_url = str_replace("https://images-na.ssl-images-amazon.com", "http://ecx.images-amazon.com", $img_url);
				
				$data->Poster = $img_url;
	        }
	    }

	    $data->Response = 'True';

   		return $data;
	}

	return false;
}


?>